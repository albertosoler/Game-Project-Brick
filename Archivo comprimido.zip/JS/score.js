function drawScore(){
 
    ctx.font="18px Arial";
    ctx.fillStyle="#f9c243";
    ctx.fillText("score: "+ brick.score,20,20);
 
 }

  
